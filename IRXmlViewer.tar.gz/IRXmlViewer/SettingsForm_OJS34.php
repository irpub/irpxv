<?php

/**
 * @file plugins/generic/IRXmlViewer/SettingsForm.php
 *
 * # Licença de Uso Exclusivo:
 * # Este código é proprietário e confidencial. Seu uso é estritamente limitado a assinantes
 * # que tenham pago a taxa de assinatura mensal. Qualquer uso não autorizado, reprodução ou modificação
 * # deste código é estritamente proibido. Para consultas sobre licenciamento e assinatura,
 * # entre em contato com IR Publicações e Desenvolvimento.
 *
 * # Exclusive Use License:
 * # This code is proprietary and confidential. Its use is strictly limited to subscribers
 * # who have paid the monthly subscription fee. Any unauthorized use, reproduction, or modification
 * # of this code is strictly prohibited. For inquiries regarding licensing and subscription,
 * # please contact IR Publicações e Desenvolvimento.
 *
 * @class SettingsForm
 * @brief Form for journal managers to modify IRXmlViewer plugin settings
 */

namespace APP\plugins\generic\IRXmlViewer;

use APP\template\TemplateManager;
use PKP\form\Form;

class SettingsForm extends Form
{
    /** @var int */
    protected $_journalId;

    /** @var IRXmlViewerPlugin */
    protected $_plugin;

    /**
     * Constructor
     *
     * @param IRXmlViewerPlugin $plugin
     * @param int $journalId
     */
    public function __construct($plugin, $journalId)
    {
        $this->_journalId = $journalId;
        $this->_plugin = $plugin;

        parent::__construct($plugin->getTemplateResource('settingsForm.tpl'));
        $this->addCheck(new \PKP\form\validation\FormValidatorPost($this));
        $this->addCheck(new \PKP\form\validation\FormValidatorCSRF($this));
    }

    /**
     * Initialize form data.
     */
    public function initData()
    {
        $journalId = $this->_journalId;
        $plugin = $this->_plugin;

        $this->setData('showCitation', $plugin->getSetting($journalId, 'showCitation'));
    }

    /**
     * Assign form data to user-submitted data.
     */
    public function readInputData()
    {
        $this->readUserVars(['showCitation']);

        // Ensure 'showCitation' is either '1' or '0'
        if (!in_array($this->getData('showCitation'), ['1', '0'], true)) {
            $this->setData('showCitation', '0'); // Default: Do not show
        }
    }

    /**
     * Fetch the form.
     *
     * @copydoc Form::fetch()
     *
     * @param \APP\core\Request $request
     * @param null|string $template
     * @param bool $display
     *
     * @return string
     */
    public function fetch($request, $template = null, $display = false)
    {
        $templateMgr = TemplateManager::getManager($request);
        $templateMgr->assign('pluginName', $this->_plugin->getName());
        $templateMgr->assign('showCitation', $this->getData('showCitation'));
        return parent::fetch($request, $template, $display);
    }

    /**
     * @copydoc Form::execute()
     */
    public function execute(...$functionArgs)
    {
        $plugin = $this->_plugin;
        $journalId = $this->_journalId;

        $plugin->updateSetting($journalId, 'showCitation', $this->getData('showCitation'));

        parent::execute(...$functionArgs);
    }
}
