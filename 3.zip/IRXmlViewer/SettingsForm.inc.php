<?php

/**
 * @file plugins/generic/IRXmlViewer/SettingsForm.inc.php
 *
 * # Licença de Uso Exclusivo:
 * # Este código é proprietário e confidencial. Seu uso é estritamente limitado a assinantes
 * # que tenham pago a taxa de assinatura mensal. Qualquer uso não autorizado, reprodução ou modificação
 * # deste código é estritamente proibido. Para consultas sobre licenciamento e assinatura,
 * # entre em contato com IR Publicações e Desenvolvimento.
 *
 * # Exclusive Use License:
 * # This code is proprietary and confidential. Its use is strictly limited to subscribers
 * # who have paid the monthly subscription fee. Any unauthorized use, reproduction, or modification
 * # of this code is strictly prohibited. For inquiries regarding licensing and subscription,
 * # please contact IR Publicações e Desenvolvimento.
 *
 * @class SettingsForm
 * @brief Formulário para gerentes de revista modificarem as configurações do plugin IRXmlViewer
 * 
 */

import('lib.pkp.classes.form.Form');

class SettingsForm extends Form
{
    /** @var int */
    protected $_journalId;

    /** @var IRXmlViewerPlugin */
    protected $_plugin;

    /**
     * Construtor
     *
     * @param IRXmlViewerPlugin $plugin
     * @param int $journalId
     */
    public function __construct($plugin, $journalId)
    {
        $this->_journalId = $journalId;
        $this->_plugin = $plugin;

        parent::__construct($plugin->getTemplateResource('settingsForm.tpl'));
        $this->addCheck(new FormValidatorPost($this));
        $this->addCheck(new FormValidatorCSRF($this));
    }

    /**
     * Inicializar dados do formulário.
     */
    public function initData()
    {
        $journalId = $this->_journalId;
        $plugin = $this->_plugin;

        $this->setData('showCitation', $plugin->getSetting($journalId, 'showCitation'));
    }

    /**
     * Atribuir dados do formulário aos dados submetidos pelo usuário.
     */
    public function readInputData()
    {
        $this->readUserVars(array('showCitation'));

        // Garantir que 'showCitation' seja '1' ou '0'
        if (!in_array($this->getData('showCitation'), array('1', '0'), true)) {
            $this->setData('showCitation', '0'); // Padrão: Não mostrar
        }
    }

    /**
     * Renderizar o formulário.
     *
     * @param $request PKPRequest
     * @param null|string $template
     * @param bool $display
     *
     * @return string
     */
    public function fetch($request, $template = null, $display = false)
    {
        $templateMgr = TemplateManager::getManager($request);
		$templateMgr->assign('pluginName', $this->_plugin->getName());
        $templateMgr->assign('showCitation', $this->getData('showCitation'));
        return parent::fetch($request, $template, $display);
    }

    /**
     * Salvar configurações.
     */
    function execute(...$functionArgs) {
		$plugin = $this->_plugin;
        $journalId = $this->_journalId;

        $plugin->updateSetting($journalId, 'showCitation', $this->getData('showCitation'));

        parent::execute();
    }
}
