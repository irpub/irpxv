<?php

require_once('IRXmlViewerPlugin.php');

return new IRXmlViewerPlugin();

?>
