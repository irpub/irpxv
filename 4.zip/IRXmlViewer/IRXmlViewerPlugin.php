<?php

/**
    # Licença de Uso Exclusivo:
    # Este código é proprietário e confidencial. Seu uso é estritamente limitado a assinantes
    # que tenham pago a taxa de assinatura mensal. Qualquer uso não autorizado, reprodução ou modificação
    # deste código é estritamente proibido. Para consultas sobre licenciamento e assinatura,
    # entre em contato com IR Publicações e Desenvolvimento.

    # Exclusive Use License:
    # This code is proprietary and confidential. Its use is strictly limited to subscribers
    # who have paid the monthly subscription fee. Any unauthorized use, reproduction, or modification
    # of this code is strictly prohibited. For inquiries regarding licensing and subscription,
    # please contact IR Publicações e Desenvolvimento.
 */

namespace APP\plugins\generic\IRXmlViewer;

use APP\core\Application;
use APP\core\Request;
use APP\core\Services;
use APP\facades\Repo;
use APP\file\PublicFileManager;
use APP\observers\events\UsageEvent;
use APP\template\TemplateManager;
use PKP\core\JSONMessage;
use PKP\plugins\GenericPlugin;
use PKP\config\Config;
use PKP\core\PKPRequest;
use PKP\galley\Galley;
use PKP\plugins\Hook;
use PKP\submissionFile\SubmissionFile;
use PKP\linkAction\LinkAction;
use PKP\linkAction\request\AjaxModal;
use APP\plugins\generic\IRXmlViewer\SettingsForm;

class IRXmlViewerPlugin extends \PKP\plugins\GenericPlugin
{
    /**
     * @copydoc LazyLoadPlugin::register()
     *
     * @param null|mixed $mainContextId
     */
    public function register($category, $path, $mainContextId = null)
    {
        if (parent::register($category, $path, $mainContextId)) {
            if ($this->getEnabled()) {
                // Add the minor update check
                $this->checkForMinorUpdates();
                // Existing hooks
                Hook::add('ArticleHandler::view::galley', $this->articleCallback(...));
                Hook::add('IssueHandler::view::galley', $this->issueCallback(...));
                Hook::add('ArticleHandler::download', $this->articleDownloadCallback(...), Hook::SEQUENCE_LATE);
                Hook::add('ArticleHandler::view::galley', [$this, 'callbackAddLinks']);
            }
            return true;
        }
        return false;
    }

    /**
     * Install default settings on journal creation.
     *
     * @return string
     */
    public function getContextSpecificPluginSettingsFile()
    {
        return $this->getPluginPath() . '/settings.xml';
    }

    /**
     * Get the display name of this plugin.
     *
     * @return string
     */
    public function getDisplayName()
    {
        return __('plugins.generic.IRXmlViewer.displayName');
    }

    /**
     * Get a description of the plugin.
     */
    public function getDescription()
    {
        return __('plugins.generic.IRXmlViewer.description');
    }

    /**
     * Callback that renders the article galley.
     *
     * @param string $hookName
     * @param array $args
     *
     * @return bool
     */
    public function articleCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];
        $submission = &$args[3];

        $templateMgr = TemplateManager::getManager($request);
        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $galleyPublication = null;
            foreach ($submission->getData('publications') as $publication) {
                if ($publication->getId() === $galley->getData('publicationId')) {
                    $galleyPublication = $publication;
                    break;
                }
            }
            $context = $request->getContext();
            $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;
            $showCitation = $this->getSetting($contextId, 'showCitation');
            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'article' => $submission,
                'bestId' => $galleyPublication->getData('urlPath') ?? $submission->getId(),
                'isLatestPublication' => $submission->getData('currentPublicationId') === $galley->getData('publicationId'),
                'galleyPublication' => $galleyPublication,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
                'showCitation' => $showCitation,
            ]);
            $templateMgr->display($this->getTemplateResource('article.tpl'));
            return true;
        }

        return false;
    }

    /**
     * Callback that renders the issue galley.
     *
     * @param string $hookName
     * @param array $args
     *
     * @return bool
     */
    public function issueCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];

        $templateMgr = TemplateManager::getManager($request);
        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $context = $request->getContext();
            $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;
            $showCitation = $this->getSetting($contextId, 'showCitation');
            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
                'showCitation' => $showCitation,
            ]);
            $templateMgr->display($this->getTemplateResource('issue.tpl'));
            return true;
        }

        return false;
    }

    /**
     * Get the URL for JQuery JS.
     *
     * @param PKPRequest $request
     *
     * @return string
     */
    private function _getJQueryUrl($request)
    {
        $min = Config::getVar('general', 'enable_minified') ? '.min' : '';
        return $request->getBaseUrl() . '/lib/pkp/lib/vendor/components/jquery/jquery' . $min . '.js';
    }

    /**
     * returns the base path for IRXml JS included in this plugin.
     *
     * @param PKPRequest $request
     *
     * @return string
     */
    public function getIRXmlPath($request)
    {
        return $request->getBaseUrl() . '/' . $this->getPluginPath() . '/lib/irxml';
    }

    /**
     * Present rewritten XML.
     *
     * @param string $hookName
     * @param array $args
     */
    public function articleDownloadCallback($hookName, $args)
    {
        $article = &$args[0];
        $galley = &$args[1];
        $fileId = &$args[2];
        $request = Application::get()->getRequest();

        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml']) && $galley->getData('submissionFileId') == $fileId) {
            if (!Hook::run('IRXmlViewerPlugin::articleDownload', [[$article, &$galley, &$fileId]])) {
                $xmlContents = $this->_getXMLContents($request, $galley);
                header('Content-Type: application/xml');
                header('Content-Length: ' . strlen($xmlContents));
                header('Content-Disposition: inline');
                header('Cache-Control: private');
                header('Pragma: public');
                echo $xmlContents;
                $returner = true;
                Hook::run('IRXmlViewerPlugin::articleDownloadFinished', [[&$returner]]);

                $submissionFile = Repo::submissionFile()->get($galley->getData('submissionFileId'));
                $publication = Repo::publication()->get($galley->getData('publicationId'));
                $issue = null;
                if ($publication->getData('issueId')) {
                    $issue = Repo::issue()->get($publication->getData('issueId'));
                    $issue = $issue->getJournalId() == $article->getData('contextId') ? $issue : null;
                }
                event(new UsageEvent(Application::ASSOC_TYPE_SUBMISSION_FILE, $request->getContext(), $article, $galley, $submissionFile, $issue));
            }
            return true;
        }

        return false;
    }

    /**
     * Return string containing the contents of the XML file.
     * This function performs any necessary filtering, like image URL replacement.
     *
     * @param Request $request
     * @param Galley $galley
     *
     * @return string
     */
    public function _getXMLContents($request, $galley)
    {
        $journal = $request->getJournal();
        $submissionFile = $galley->getFile();
        $fileService = Services::get('file');
        $file = $fileService->get($submissionFile->getData('fileId'));
        $contents = $fileService->fs->read($file->path);

        // Carregar o XML no DOMDocument
        $dom = new \DOMDocument();
        $dom->loadXML($contents, LIBXML_NOBLANKS);

        // Obtém o <body> do artigo principal
        $mainBody = $dom->getElementsByTagName('body')->item(0);

        // Obtém o <sub-article>, se existir
        $subArticle = $dom->getElementsByTagName('sub-article')->item(0);

        if ($subArticle) {
            $subArticleLang = $subArticle->getAttribute('xml:lang');
            $subArticleBody = $subArticle->getElementsByTagName('body')->item(0);

            if ($mainBody && $subArticleBody) {
                // Criar um novo <sec> com um <title> dentro
                $secElement = $dom->createElement('sec');
                $secElement->setAttribute('sec-type', $subArticleLang);
                $secElement->setAttribute('xml:lang', $subArticleLang);

                $pElement = $dom->createElement('title', strtoupper($subArticleLang));
                $secElement->appendChild($pElement);

                $mainBody->appendChild($secElement);

                // Mover os nós filhos de <sub-article> <body> para <article> <body>
                while ($subArticleBody->firstChild) {
                    $node = $subArticleBody->removeChild($subArticleBody->firstChild);
                    $mainBody->appendChild($dom->importNode($node, true));
                }
            }

            // Mover <fn-group> do <sub-article> para <article> <back>
            $mainBack = $dom->getElementsByTagName('back')->item(0);
            if ($mainBack) {
                $subArticleFnGroups = $subArticle->getElementsByTagName('fn-group');
                foreach ($subArticleFnGroups as $fnGroup) {
                    $importedFnGroup = $dom->importNode($fnGroup, true);
                    $importedFnGroup->setAttribute('fn-group-lang', $subArticleLang);
                    $mainBack->appendChild($importedFnGroup);
                }
            }
        } else {
            error_log('Nenhum <sub-article> encontrado. Prosseguindo normalmente.');
        }

        // Salvar as modificações no XML
        $contents = $dom->saveXML();

        // Substituir extensões de imagem .tif por .jpg
        $contents = str_replace('.tif"/>', '.jpg"/>', $contents);

        // Processamento normal do XML sem necessidade de <sub-article>
        $embeddableFiles = Repo::submissionFile()
            ->getCollector()
            ->filterByAssoc(
                Application::ASSOC_TYPE_SUBMISSION_FILE,
                [$submissionFile->getId()]
            )
            ->filterByFileStages([SubmissionFile::SUBMISSION_FILE_DEPENDENT])
            ->includeDependentFiles()
            ->getMany();

        $referredArticle = $referredPublication = null;
        foreach ($embeddableFiles as $embeddableFile) {
            if (
                !$referredArticle || !$referredPublication ||
                $referredPublication->getData('submissionId') != $referredArticle->getId() ||
                $referredPublication->getId() != $galley->getData('publicationId')
            ) {

                $referredPublication = Repo::publication()->get($galley->getData('publicationId'));
                $referredArticle = Repo::submission()->get($referredPublication->getData('submissionId'));
            }

            $fileUrl = $request->url(null, 'article', 'download', [
                $referredPublication->getData('urlPath') ?? $referredArticle->getId(),
                $galley->getBestGalleyId(),
                $embeddableFile->getId()
            ]);

            $pattern = preg_quote(rawurlencode($embeddableFile->getLocalizedData('name')), '/');

            $contents = preg_replace(
                '/([Ss][Rr][Cc]|[Hh][Rr][Ee][Ff]|[Dd][Aa][Tt][Aa])\s*=\s*"([^"]*' . $pattern . ')"/',
                '\1="' . $fileUrl . '"',
                $contents
            );

            if ($contents === null) {
                error_log('PREG error in ' . __FILE__ . ' line ' . __LINE__ . ': ' . preg_last_error());
            }
        }

        // Processamento de URLs ojs://
        $contents = preg_replace_callback(
            '/(<[^<>]*")[Oo][Jj][Ss]:\/\/([^"]+)("[^<>]*>)/',
            [$this, '_handleOjsUrl'],
            $contents
        );

        if ($contents === null) {
            error_log('PREG error in ' . __FILE__ . ' line ' . __LINE__ . ': ' . preg_last_error());
        }

        // Substituir variáveis de journal, issue e site
        $submissionFileAux = $galley->getFile();
        $submissionIdAux = $submissionFileAux->getData('submissionId');

        $issue = Repo::issue()->getBySubmissionId($submissionIdAux);
        $journal = $request->getJournal();
        $site = $request->getSite();

        $paramArray = [
            'issueTitle' => $issue ? $issue->getIssueIdentification() : __('editor.article.scheduleForPublication.toBeAssigned'),
            'journalTitle' => $journal->getLocalizedName(),
            'siteTitle' => $site->getLocalizedTitle(),
            'currentUrl' => $request->getRequestUrl(),
        ];

        foreach ($paramArray as $key => $value) {
            $contents = str_replace('{$' . $key . '}', $value ?? '', $contents);
        }

        // Substituição de entidades HTML
        $contents = str_replace('&amp;', '@@1AMP1@@', $contents);
        $contents = str_replace('&gt;', '@@1GT1@@', $contents);
        $contents = str_replace('&lt;', '@@1LT1@@', $contents);

        $contents = html_entity_decode($contents, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $contents = str_replace(['@@1LT1@@', '@@1GT1@@', '@@1AMP1@@'], ['&lt;', '&gt;', '&amp;'], $contents);

        return $contents;
    }

    public function _handleOjsUrl($matchArray)
    {
        $request = Application::get()->getRequest();
        $url = $matchArray[2];
        $anchor = null;
        if (($i = strpos($url, '#')) !== false) {
            $anchor = substr($url, $i + 1);
            $url = substr($url, 0, $i);
        }
        $urlParts = explode('/', $url);
        if (isset($urlParts[0])) {
            switch (strtolower_codesafe($urlParts[0])) {
                case 'journal':
                    $url = $request->url(
                        $urlParts[1] ?? $request->getRouter()->getRequestedContextPath($request),
                        null,
                        null,
                        null,
                        null,
                        $anchor
                    );
                    break;
                case 'article':
                    if (isset($urlParts[1])) {
                        $url = $request->url(
                            null,
                            'article',
                            'view',
                            $urlParts[1],
                            null,
                            $anchor
                        );
                    }
                    break;
                case 'issue':
                    if (isset($urlParts[1])) {
                        $url = $request->url(
                            null,
                            'issue',
                            'view',
                            $urlParts[1],
                            null,
                            $anchor
                        );
                    } else {
                        $url = $request->url(
                            null,
                            'issue',
                            'current',
                            null,
                            null,
                            $anchor
                        );
                    }
                    break;
                case 'sitepublic':
                    array_shift($urlParts);
                    $publicFileManager = new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getSiteFilesPath() . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
                case 'public':
                    array_shift($urlParts);
                    $journal = $request->getJournal();
                    $publicFileManager = new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getContextFilesPath($journal->getId()) . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
            }
        }
        return $matchArray[1] . $url . $matchArray[3];
    }

    public function callbackAddLinks($hookName, $args)
    {
        $request = Application::get()->getRequest();
        if ($this->getEnabled() && is_a($request->getRouter(), 'PKPPageRouter')) {
            $templateManager = $args[0];
            $currentJournal = $templateManager->getTemplateVars('currentJournal');

            $displayPage = $currentJournal ? $this->getSetting($currentJournal->getId(), 'displayPage') : null;
        }

        return false;
    }

    public function getActions($request, $verb)
    {
        $router = $request->getRouter();
        return array_merge(
            $this->getEnabled($request->getContext()->getId()) ? [
                new LinkAction(
                    'settings',
                    new AjaxModal(
                        $router->url($request, null, null, 'manage', null, ['verb' => 'settings', 'plugin' => $this->getName(), 'category' => 'generic']),
                        $this->getDisplayName()
                    ),
                    __('manager.plugins.settings'),
                    null
                ),
            ] : [],
            parent::getActions($request, $verb)
        );
    }

    public function manage($args, $request)
    {
        switch ($request->getUserVar('verb')) {
            case 'settings':
                $context = $request->getContext();
                $templateMgr = TemplateManager::getManager($request);
                $templateMgr->registerPlugin('function', 'plugin_url', [$this, 'smartyPluginUrl']);

                // Ler a versão aqui
                $versionFilePath = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'version.txt';
                if (file_exists($versionFilePath)) {
                    $version = trim(file_get_contents($versionFilePath));
                } else {
                    $version = 'Desconhecida';
                }
                $templateMgr->assign('pluginVersion', $version);

                // Certificar que a classe SettingsForm está disponível
                $form = new SettingsForm($this, $context->getId());

                if ($request->getUserVar('save') || $request->getUserVar('forceUpdate')) {
                    $form->readInputData();
                    if ($form->validate()) {
                        $form->execute();
                        if ($request->getUserVar('forceUpdate')) {
                            $updateResult = $this->forceUpdate();
                            if ($updateResult['success']) {
                                return new JSONMessage(true, __('plugins.generic.IRXmlViewer.updateSuccess'));
                            } else {
                                return new JSONMessage(true, $updateResult['message']);
                            }
                        }
                        return new JSONMessage(true);
                    }
                } else {
                    $form->initData();
                }
                return new JSONMessage(true, $form->fetch($request));
        }
        return parent::manage($args, $request);
    }

    public function forceUpdate()
    {
        $errors = [];

        // Download update.zip
        $updateZipUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/4.zip';
        $updateZipPath = $this->getPluginPath() . '/update.zip';

        $downloaded = @file_put_contents($updateZipPath, fopen($updateZipUrl, 'r'));
        if (!$downloaded) {
            $errors[] = 'Erro: Falha ao baixar o arquivo update.zip da URL: ' . $updateZipUrl;
            $this->logErrors($errors);
            return ['success' => false, 'message' => '<br><b>Erro 101 - Falha ao baixar os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 101.<br>'];
        }

        // Unzip update.zip into a temporary directory
        $zip = new \ZipArchive;
        if ($zip->open($updateZipPath) === TRUE) {
            $extractPath = $this->getPluginPath() . '/update_temp';
            if (!$zip->extractTo($extractPath)) {
                $errors[] = 'Erro: Falha ao extrair o arquivo update.zip para o diretório temporário.';
                $this->logErrors($errors);
                $zip->close();
                unlink($updateZipPath);
                return ['success' => false, 'message' => '<br><b>Erro 102 - Falha ao extrair os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 102.<br>'];
            }
            $zip->close();
        } else {
            $errors[] = 'Erro: Não foi possível abrir o arquivo update.zip.';
            $this->logErrors($errors);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 103 - Falha ao abrir os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 103.<br>'];
        }

        // Now, replace plugin files with the ones from the update
        if (!$this->recurseCopy($extractPath, $this->getPluginPath())) {
            $errors[] = 'Erro: Falha ao copiar os arquivos do diretório de atualização para o diretório do plugin.';
            $this->logErrors($errors);
            $this->rrmdir($extractPath);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 104 - Falha ao aplicar a atualização</b><br>Acesse a documentação para mais informações sobre o erro 104.<br>'];
        }

        // Remove the temporary files
        $this->rrmdir($extractPath);
        unlink($updateZipPath);

        // Now, check for updates
        $remoteVersionUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/version3';

        // Read remote version
        $remoteVersion = trim(@file_get_contents($remoteVersionUrl));

        // Atualiza o arquivo de versão local
        $localVersionFile = $this->getPluginPath() . '/version.txt';
        file_put_contents($localVersionFile, $remoteVersion);

        // Update success
        return ['success' => true];
    }

    public function checkForMinorUpdates()
    {
        $context = Application::get()->getRequest()->getContext();
        $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;

        // Pega o horário da última verificação
        $lastCheckTime = $this->getSetting($contextId, 'lastUpdateCheck');
        $currentTime = time();

        $localVersionFile = $this->getPluginPath() . '/version.txt';

        // Lê a versão local
        if (!file_exists($localVersionFile)) {
            // Sem arquivo de versão local, assume versão 0.0.0
            $localVersion = '0.0.0';
        } else {
            $localVersion = trim(file_get_contents($localVersionFile));
        }

        // Verifica se já se passou um período adequado desde a última checagem
        if ($lastCheckTime && ($currentTime - $lastCheckTime) < 28800 && $localVersion != '0.0.0') {
            // Menos de oito horas desde a última verificação, nada a fazer
            return;
        }

        // Atualiza o horário da última verificação
        $this->updateSetting($contextId, 'lastUpdateCheck', $currentTime);

        // Agora, verifica atualizações
        $remoteVersionUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/version4';

        // Lê a versão remota
        $remoteVersion = trim(@file_get_contents($remoteVersionUrl));
        if (!$remoteVersion) {
            // Não foi possível obter a versão remota, aborta
            return;
        }

        // Compara as versões
        if (version_compare($remoteVersion, $localVersion, '>')) {
            // A versão remota é mais recente, procede com a atualização
            $this->performMinorUpdate($remoteVersion);
        }
    }

    public function performMinorUpdate($newVersion)
    {
        $errors = [];

        // Baixar update.zip
        $updateZipUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/4.zip';
        $updateZipPath = $this->getPluginPath() . '/update.zip';

        $downloaded = @file_put_contents($updateZipPath, fopen($updateZipUrl, 'r'));
        if (!$downloaded) {
            $errors[] = 'Erro: Falha ao baixar o arquivo update.zip da URL: ' . $updateZipUrl;
            $this->logErrors($errors);
            return ['success' => false, 'message' => '<br><b>Erro 101 - Falha ao baixar os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 101.<br>'];
        }

        // Extrair update.zip para um diretório temporário
        $zip = new \ZipArchive;
        if ($zip->open($updateZipPath) === TRUE) {
            $extractPath = $this->getPluginPath() . '/update_temp';
            if (!$zip->extractTo($extractPath)) {
                $errors[] = 'Erro: Falha ao extrair o arquivo update.zip para o diretório temporário.';
                $this->logErrors($errors);
                $zip->close();
                unlink($updateZipPath);
                return ['success' => false, 'message' => '<br><b>Erro 102 - Falha ao extrair os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 102.<br>'];
            }
            $zip->close();
        } else {
            $errors[] = 'Erro: Não foi possível abrir o arquivo update.zip.';
            $this->logErrors($errors);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 103 - Falha ao abrir os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 103.<br>'];
        }

        // Agora, substitua os arquivos do plugin pelos arquivos da atualização
        if (!$this->recurseCopy($extractPath, $this->getPluginPath())) {
            $errors[] = 'Erro: Falha ao copiar os arquivos do diretório de atualização para o diretório do plugin.';
            $this->logErrors($errors);
            $this->rrmdir($extractPath);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 104 - Falha ao aplicar a atualização</b><br>Acesse a documentação para mais informações sobre o erro 104.<br>'];
        }

        // Remove os arquivos temporários
        $this->rrmdir($extractPath);
        unlink($updateZipPath);

        // Atualiza o arquivo de versão local
        $localVersionFile = $this->getPluginPath() . '/version.txt';
        file_put_contents($localVersionFile, $newVersion);

        // Atualização bem-sucedida
        return ['success' => true];
    }

    private function logErrors($errors)
    {
        $errorLogPath = $this->getPluginPath() . '/errors.txt';
        $errorMessages = "[" . date('Y-m-d H:i:s') . "]\n";
        foreach ($errors as $error) {
            $errorMessages .= $error . "\n";
        }
        file_put_contents($errorLogPath, $errorMessages, FILE_APPEND);
    }

    private function recurseCopy($src, $dst)
    {
        $dir = opendir($src);
        if (!$dir) {
            return false;
        }
        if (!is_dir($dst)) {
            if (!mkdir($dst, 0755, true)) {
                return false;
            }
        }
        while (($file = readdir($dir)) !== false) {
            if ($file != '.' && $file != '..') {
                if (is_dir($src . '/' . $file)) {
                    if (!$this->recurseCopy($src . '/' . $file, $dst . '/' . $file)) {
                        return false;
                    }
                } else {
                    if (!copy($src . '/' . $file, $dst . '/' . $file)) {
                        return false;
                    }
                }
            }
        }
        closedir($dir);
        return true;
    }

    private function rrmdir($dir)
    {
        // Define o caminho para o arquivo de log de erros
        $errorLogFile = $this->getPluginPath() . '/errors.txt';

        if (is_dir($dir)) {
            $objects = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::CHILD_FIRST
            );

            foreach ($objects as $object) {
                $path = $object->getPathname();
                if ($object->isDir()) {
                    if (!rmdir($path)) {
                        // Log de erro com data e hora em errors.txt
                        file_put_contents(
                            $errorLogFile,
                            '[' . date('Y-m-d H:i:s') . '] Falha ao remover o diretório: ' . $path . PHP_EOL,
                            FILE_APPEND
                        );
                    }
                } else {
                    if (!unlink($path)) {
                        // Log de erro com data e hora em errors.txt
                        file_put_contents(
                            $errorLogFile,
                            '[' . date('Y-m-d H:i:s') . '] Falha ao deletar o arquivo: ' . $path . PHP_EOL,
                            FILE_APPEND
                        );
                    }
                }
            }

            if (!rmdir($dir)) {
                // Log de erro com data e hora em errors.txt
                file_put_contents(
                    $errorLogFile,
                    '[' . date('Y-m-d H:i:s') . '] Falha ao remover o diretório raiz: ' . $dir . PHP_EOL,
                    FILE_APPEND
                );
            }
        } else {
            // Log de erro com data e hora em errors.txt
            file_put_contents(
                $errorLogFile,
                '[' . date('Y-m-d H:i:s') . '] Diretório não existe ou não é um diretório: ' . $dir . PHP_EOL,
                FILE_APPEND
            );
        }
    }

}
