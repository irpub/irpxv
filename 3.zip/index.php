<?php

require_once('IRXmlViewerPlugin.inc.php');

return new IRXmlViewerPlugin();

?>
