<?php

/**
 * @file plugins/generic/IRXmlViewer/IRXmlViewerPlugin.php
 *
 * # Licença de Uso Exclusivo:
 * # Este código é proprietário e confidencial. Seu uso é estritamente limitado a assinantes
 * # que tenham pago a taxa de assinatura mensal. Qualquer uso não autorizado, reprodução ou modificação
 * # deste código é estritamente proibido. Para consultas sobre licenciamento e assinatura,
 * # entre em contato com IR Publicações e Desenvolvimento.
 *
 * # Exclusive Use License:
 * # This code is proprietary and confidential. Its use is strictly limited to subscribers
 * # who have paid the monthly subscription fee. Any unauthorized use, reproduction, or modification
 * # of this code is strictly prohibited. For inquiries regarding licensing and subscription,
 * # please contact IR Publicações e Desenvolvimento.
 *
 * @class IRXmlViewerPlugin
 * @brief Plugin unificado para visualização de XML para OJS 3.3+ e OJS 3.4+
 */

// Estratégia de compatibilidade mais robusta para diferentes versões do OJS
if (class_exists('APP\core\Application')) {
    // OJS 3.4+ - usa namespaces
    class IRXmlViewerPlugin extends \PKP\plugins\GenericPlugin {
        use IRXmlViewerPluginTrait;
    }
} else {
    // OJS 3.3 e anteriores - sem namespaces
    import('lib.pkp.classes.plugins.GenericPlugin');
    class IRXmlViewerPlugin extends GenericPlugin {
        use IRXmlViewerPluginTrait;
    }
}

/**
 * Trait que contém toda a lógica do plugin, independente da versão do OJS
 */
trait IRXmlViewerPluginTrait
{
    /** @var bool|null Cache para a verificação da versão do OJS. */
    private static $isOJS34 = null;

    /**
     * Verifica se a versão do OJS é 3.4 ou superior.
     * @return bool
     */
    private function isOJS34() {
        if (self::$isOJS34 === null) {
            self::$isOJS34 = class_exists('APP\core\Application');
        }
        return self::$isOJS34;
    }

    /**
     * @copydoc Plugin::register()
     */
    public function register($category, $path, $mainContextId = null)
    {
        if (parent::register($category, $path, $mainContextId)) {
            if ($this->getEnabled()) {
                if ($this->isOJS34()) {
                    // --- Lógica para OJS 3.4+ ---
                    \PKP\plugins\Hook::add('ArticleHandler::view::galley', $this->articleCallback(...));
                    \PKP\plugins\Hook::add('IssueHandler::view::galley', $this->issueCallback(...));
                    \PKP\plugins\Hook::add('ArticleHandler::download', $this->articleDownloadCallback(...), \PKP\plugins\Hook::SEQUENCE_LATE);
                } else {
                    // --- Lógica para OJS < 3.4 ---
                    if (!class_exists('HookRegistry')) import('lib.pkp.classes.plugins.HookRegistry');
                    HookRegistry::register('ArticleHandler::view::galley', array($this, 'articleCallback'));
                    HookRegistry::register('IssueHandler::view::galley', array($this, 'issueCallback'));
                    HookRegistry::register('ArticleHandler::download', array($this, 'articleDownloadCallback'), HOOK_SEQUENCE_LATE);
                }
            }
            return true;
        }
        return false;
    }

    /**
     * @copydoc Plugin::getContextSpecificPluginSettingsFile()
     */
    public function getContextSpecificPluginSettingsFile()
    {
        return $this->getPluginPath() . '/settings.xml';
    }

    /**
     * @copydoc Plugin::getDisplayName()
     */
    public function getDisplayName()
    {
        return __('plugins.generic.IRXmlViewer.displayName');
    }

    /**
     * @copydoc Plugin::getDescription()
     */
    public function getDescription()
    {
        return __('plugins.generic.IRXmlViewer.description');
    }

    /**
     * Obtém o TemplateManager de forma compatível com ambas as versões
     */
    private function getTemplateManager($request)
    {
        if ($this->isOJS34()) {
            return \APP\template\TemplateManager::getManager($request);
        } else {
            return TemplateManager::getManager($request);
        }
    }

    /**
     * Obtém o Request de forma compatível com ambas as versões
     */
    private function getApplication()
    {
        if ($this->isOJS34()) {
            return \APP\core\Application::get();
        } else {
            return Application::get();
        }
    }

    /**
     * Callback para renderizar a prova (galley) de um artigo.
     */
    public function articleCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];
        $submission = &$args[3];

        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $templateMgr = $this->getTemplateManager($request);

            $galleyPublication = null;
            foreach ($submission->getData('publications') as $publication) {
                if ($publication->getId() === $galley->getData('publicationId')) {
                    $galleyPublication = $publication;
                    break;
                }
            }

            $context = $request->getContext();
            $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;
            $showCitation = $this->getSetting($contextId, 'showCitation');

            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'article' => $submission,
                'bestId' => $this->isOJS34() ? ($galleyPublication->getData('urlPath') ?? $submission->getId()) : $submission->getBestId(),
                'isLatestPublication' => $submission->getData('currentPublicationId') === $galley->getData('publicationId'),
                'galleyPublication' => $galleyPublication,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
                'showCitation' => $showCitation,
            ]);

            // Seleção dinâmica de template
            $templateName = 'article.tpl';

            $templateMgr->display($this->getTemplateResource($templateName));
            return true;
        }

        return false;
    }

    /**
     * Callback para renderizar a prova (galley) de uma edição.
     */
    public function issueCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];

        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $templateMgr = $this->getTemplateManager($request);

            $context = $request->getContext();
            $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;
            $showCitation = $this->getSetting($contextId, 'showCitation');

            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
                'showCitation' => $showCitation,
            ]);

            // Seleção dinâmica de template
            $templateName = 'issue.tpl';

            $templateMgr->display($this->getTemplateResource($templateName));
            return true;
        }

        return false;
    }

    /**
     * Callback para reescrever e apresentar o XML para download.
     */
    public function articleDownloadCallback($hookName, $args)
    {
        $article = &$args[0];
        $galley = &$args[1];
        $fileId = &$args[2];

        $request = $this->getApplication()->getRequest();

        $galleyFileId = $this->isOJS34() ? $galley->getData('submissionFileId') : $galley->getFileId();

        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml']) && $galleyFileId == $fileId) {
            $hookResult = false;

            if ($this->isOJS34()) {
                $hookResult = \PKP\plugins\Hook::run('IRXmlViewerPlugin::articleDownload', [[$article, &$galley, &$fileId]]);
            } else {
                $hookResult = HookRegistry::call('IRXmlViewerPlugin::articleDownload', array($article, &$galley, &$fileId));
            }

            if (!$hookResult) {
                $xmlContents = $this->_getXMLContents($request, $galley);
                header('Content-Type: application/xml');
                header('Content-Length: ' . strlen($xmlContents));
                header('Content-Disposition: inline');
                header('Cache-Control: private');
                header('Pragma: public');
                echo $xmlContents;

                $returner = true;
                if ($this->isOJS34()) {
                    \PKP\plugins\Hook::run('IRXmlViewerPlugin::articleDownloadFinished', [[&$returner]]);
                    $submissionFile = \APP\facades\Repo::submissionFile()->get($galley->getData('submissionFileId'));
                    $publication = \APP\facades\Repo::publication()->get($galley->getData('publicationId'));
                    $issue = $publication->getData('issueId') ? \APP\facades\Repo::issue()->get($publication->getData('issueId')) : null;
                    event(new \APP\observers\events\UsageEvent(\APP\core\Application::ASSOC_TYPE_SUBMISSION_FILE, $request->getContext(), $article, $galley, $submissionFile, $issue));
                } else {
                    HookRegistry::call('IRXmlViewerPlugin::articleDownloadFinished', array(&$returner));
                }
            }
            return true;
        }

        return false;
    }

    /**
     * Retorna o conteúdo do arquivo XML com filtros e substituições aplicados.
     */
    public function _getXMLContents($request, $galley)
    {
        $services = $this->isOJS34() ? \APP\core\Services::class : 'Services';
        $fileService = $services::get('file');
        $submissionFile = $galley->getFile();
        $file = $fileService->get($submissionFile->getData('fileId'));
        $contents = $fileService->fs->read($file->path);

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        if (@$dom->loadXML($contents, LIBXML_NOBLANKS)) {
            $mainBody = $dom->getElementsByTagName('body')->item(0);
            $subArticle = $dom->getElementsByTagName('sub-article')->item(0);
            if ($subArticle && $mainBody) {
                $subArticleLang = $subArticle->getAttribute('xml:lang');
                $subArticleBody = $subArticle->getElementsByTagName('body')->item(0);
                if ($subArticleBody) {
                    $secElement = $dom->createElement('sec');
                    $secElement->setAttribute('sec-type', $subArticleLang);
                    $secElement->setAttribute('xml:lang', $subArticleLang);
                    $pElement = $dom->createElement('title', strtoupper($subArticleLang));
                    $secElement->appendChild($pElement);
                    $mainBody->appendChild($secElement);
                    while ($subArticleBody->firstChild) {
                        $node = $subArticleBody->removeChild($subArticleBody->firstChild);
                        $mainBody->appendChild($dom->importNode($node, true));
                    }
                }
                $mainBack = $dom->getElementsByTagName('back')->item(0);
                if ($mainBack) {
                    $subArticleFnGroups = $subArticle->getElementsByTagName('fn-group');
                    foreach ($subArticleFnGroups as $fnGroup) {
                        $importedFnGroup = $dom->importNode($fnGroup, true);
                        $importedFnGroup->setAttribute('fn-group-lang', $subArticleLang);
                        $mainBack->appendChild($importedFnGroup);
                    }
                }
            }
            $contents = $dom->saveXML();
        }
        libxml_clear_errors();

        $contents = str_replace('.tif"/>', '.jpg"/>', $contents);

        if ($this->isOJS34()) {
            $embeddableFiles = \APP\facades\Repo::submissionFile()
                ->getCollector()
                ->filterByAssoc(\APP\core\Application::ASSOC_TYPE_SUBMISSION_FILE, [$submissionFile->getId()])
                ->filterByFileStages([\PKP\submissionFile\SubmissionFile::SUBMISSION_FILE_DEPENDENT])
                ->includeDependentFiles()
                ->getMany();
            foreach ($embeddableFiles as $embeddableFile) {
                $referredPublication = \APP\facades\Repo::publication()->get($galley->getData('publicationId'));
                $referredArticle = \APP\facades\Repo::submission()->get($referredPublication->getData('submissionId'));
                $fileUrl = $request->url(null, 'article', 'download', [
                    $referredPublication->getData('urlPath') ?? $referredArticle->getId(),
                    $galley->getBestGalleyId(),
                    $embeddableFile->getId()
                ]);
                $pattern = preg_quote(rawurlencode($embeddableFile->getLocalizedData('name')), '/');
                $contents = preg_replace('/([Ss][Rr][Cc]|[Hh][Rr][Ee][Ff]|[Dd][Aa][Tt][Aa])\s*=\s*"([^"]*' . $pattern . ')"/', '\1="' . $fileUrl . '"', $contents);
            }
        } else {
            if (!class_exists('SubmissionFile')) import('lib.pkp.classes.submission.SubmissionFile');
            $embeddableFilesIterator = $services::get('submissionFile')->getMany([
                'assocTypes' => [ASSOC_TYPE_SUBMISSION_FILE], 
                'assocIds' => [$submissionFile->getId()], 
                'fileStages' => [SUBMISSION_FILE_DEPENDENT]
            ]);
            foreach ($embeddableFilesIterator as $embeddableFile) {
                $publicationService = $services::get('publication');
                $referredPublication = $publicationService->get($galley->getData('publicationId'));
                $submissionDao = DAORegistry::getDAO('SubmissionDAO');
                $referredArticle = $submissionDao->getById($referredPublication->getData('submissionId'));
                $fileUrl = $request->url(null, 'article', 'download', [$referredArticle->getBestArticleId(), $galley->getBestGalleyId(), $embeddableFile->getId()]);
                $pattern = preg_quote(rawurlencode($embeddableFile->getLocalizedData('name')));
                $contents = preg_replace('/([Ss][Rr][Cc]|[Hh][Rr][Ee][Ff]|[Dd][Aa][Tt][Aa])\s*=\s*"([^"]*' . $pattern . ')"/', '\1="' . $fileUrl . '"', $contents);
            }
        }

        $contents = preg_replace_callback('/(<[^<>]*")[Oo][Jj][Ss]:\/\/([^"]+)("[^<>]*>)/', [$this, '_handleOjsUrl'], $contents);

        $issue = $this->isOJS34() ? 
            \APP\facades\Repo::issue()->getBySubmissionId($submissionFile->getData('submissionId')) : 
            DAORegistry::getDAO('IssueDAO')->getBySubmissionId($galley->getData('submissionId'));
            
        $paramArray = [
            'issueTitle' => $issue ? $issue->getIssueIdentification() : __('editor.article.scheduleForPublication.toBeAssigned'),
            'journalTitle' => $request->getJournal()->getLocalizedName(),
            'siteTitle' => $request->getSite()->getLocalizedTitle(),
            'currentUrl' => $request->getRequestUrl(),
        ];
        foreach ($paramArray as $key => $value) {
            $contents = str_replace('{$' . $key . '}', $value ?? '', $contents);
        }

        $contents = str_replace(['&amp;', '&gt;', '&lt;'], ['@@1AMP1@@', '@@1GT1@@', '@@1LT1@@'], $contents);
        $contents = html_entity_decode($contents, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return str_replace(['@@1LT1@@', '@@1GT1@@', '@@1AMP1@@'], ['&lt;', '&gt;', '&amp;'], $contents);
    }

    /**
     * Manipula URLs ojs://
     */
    public function _handleOjsUrl($matchArray)
    {
        $request = $this->getApplication()->getRequest();
        $url = $matchArray[2];
        $anchor = null;
        if (($i = strpos($url, '#')) !== false) {
            $anchor = substr($url, $i + 1);
            $url = substr($url, 0, $i);
        }
        $urlParts = explode('/', $url);
        if (isset($urlParts[0])) {
            $contextPath = $request->getRouter()->getRequestedContextPath($request);
            switch (strtolower($urlParts[0])) {
                case 'journal': 
                    $url = $request->url($urlParts[1] ?? $contextPath, null, null, null, null, $anchor); 
                    break;
                case 'article': 
                    if (isset($urlParts[1])) $url = $request->url(null, 'article', 'view', $urlParts[1], null, $anchor); 
                    break;
                case 'issue': 
                    $url = isset($urlParts[1]) ? $request->url(null, 'issue', 'view', $urlParts[1], null, $anchor) : $request->url(null, 'issue', 'current', null, null, $anchor); 
                    break;
                case 'sitepublic':
                    array_shift($urlParts);
                    $publicFileManager = $this->isOJS34() ? new \PKP\file\PublicFileManager() : new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getSiteFilesPath() . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
                case 'public':
                    array_shift($urlParts);
                    $publicFileManager = $this->isOJS34() ? new \PKP\file\PublicFileManager() : new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getContextFilesPath($request->getJournal()->getId()) . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
            }
        }
        return $matchArray[1] . $url . $matchArray[3];
    }

    /**
     * @copydoc Plugin::getActions()
     */
    public function getActions($request, $verb)
    {
        $actions = [];
        if ($this->getEnabled($request->getContext()->getId())) {
            if ($this->isOJS34()) {
                $actions[] = new \PKP\linkAction\LinkAction(
                    'settings',
                    new \PKP\linkAction\request\AjaxModal(
                        $request->getRouter()->url($request, null, null, 'manage', null, ['verb' => 'settings', 'plugin' => $this->getName(), 'category' => 'generic']),
                        $this->getDisplayName()
                    ),
                    __('manager.plugins.settings'),
                    null
                );
            } else {
                $actions[] = new LinkAction(
                    'settings',
                    new AjaxModal(
                        $request->getRouter()->url($request, null, null, 'manage', null, ['verb' => 'settings', 'plugin' => $this->getName(), 'category' => 'generic']),
                        $this->getDisplayName()
                    ),
                    __('manager.plugins.settings'),
                    null
                );
            }
        }
        return array_merge($actions, parent::getActions($request, $verb));
    }

    /**
     * @copydoc Plugin::manage()
     */
    public function manage($args, $request)
    {
        if ($request->getUserVar('verb') === 'settings') {
            // Verificar atualizações sempre que acessar as configurações
            $this->checkForUpdates();
            
            // Carregamento condicional da classe de formulário
            if ($this->isOJS34()) {
                require_once($this->getPluginPath() . '/SettingsForm_OJS34.php');
                $formClass = '\APP\plugins\generic\IRXmlViewer\SettingsForm';
            } else {
                require_once($this->getPluginPath() . '/SettingsForm_OJS33.inc.php');
                $formClass = 'SettingsForm';
            }

            $context = $request->getContext();
            $templateMgr = $this->getTemplateManager($request);

            if ($this->isOJS34()) {
                $templateMgr->registerPlugin('function', 'plugin_url', [$this, 'smartyPluginUrl']);
            } else {
                $templateMgr->register_function('plugin_url', array($this, 'smartyPluginUrl'));
            }

            $versionFilePath = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'version.txt';
            $currentVersion = file_exists($versionFilePath) ? trim(file_get_contents($versionFilePath)) : 'Desconhecida';
            
            // Obter informações sobre atualizações (já verificadas acima)
            $contextId = $context->getId();
            $updateAvailable = $this->getSetting($contextId, 'updateAvailable');
            $showUpdateNotification = $this->getSetting($contextId, 'showUpdateNotification');
            
            $templateMgr->assign([
                'pluginVersion' => $currentVersion,
                'updateAvailable' => $updateAvailable,
                'showUpdateNotification' => $showUpdateNotification,
                'downloadUrl' => $this->getDownloadUrl()
            ]);

            $form = new $formClass($this, $context->getId());

            if ($request->getUserVar('save')) {
                $form->readInputData();
                if ($form->validate()) {
                    $this->isOJS34() ? $form->execute($request) : $form->execute();
                    $jsonMessageClass = $this->isOJS34() ? '\PKP\core\JSONMessage' : 'JSONMessage';
                    return new $jsonMessageClass(true);
                }
            } elseif ($request->getUserVar('dismissUpdate')) {
                // Dispensar notificação de atualização
                $this->updateSetting($contextId, 'showUpdateNotification', false);
                $jsonMessageClass = $this->isOJS34() ? '\PKP\core\JSONMessage' : 'JSONMessage';
                return new $jsonMessageClass(true);
            } else {
                $form->initData();
            }
            $jsonMessageClass = $this->isOJS34() ? '\PKP\core\JSONMessage' : 'JSONMessage';
            return new $jsonMessageClass(true, $form->fetch($request));
        }
        return parent::manage($args, $request);
    }

    /**
     * Verifica se há atualizações disponíveis (apenas notificação).
     * Chamada sempre que o usuário acessar as configurações do plugin.
     */
    public function checkForUpdates()
    {
        $context = $this->getApplication()->getRequest()->getContext();
        $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;
        
        $localVersion = $this->getCurrentVersion();
        $remoteVersion = $this->getRemoteVersion();
        
        if ($remoteVersion && version_compare($remoteVersion, $localVersion, '>')) {
            $this->updateSetting($contextId, 'updateAvailable', $remoteVersion);
            $this->updateSetting($contextId, 'showUpdateNotification', true);
        } else {
            // Se não há atualização disponível, limpar as configurações
            $this->updateSetting($contextId, 'updateAvailable', false);
            $this->updateSetting($contextId, 'showUpdateNotification', false);
        }
    }

    /**
     * Obtém a versão atual do plugin.
     */
    public function getCurrentVersion()
    {
        $versionFilePath = $this->getPluginPath() . '/version.txt';
        return file_exists($versionFilePath) ? trim(file_get_contents($versionFilePath)) : '0.0.0';
    }

    /**
     * Obtém a versão remota do plugin.
     */
    private function getRemoteVersion()
    {
        $versionUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/version';
        
        // Usar contexto de stream para timeout
        $context = stream_context_create([
            'http' => [
                'timeout' => 10,
                'method' => 'GET',
                'header' => 'User-Agent: IRXmlViewer Plugin'
            ]
        ]);
        
        $remoteVersion = @file_get_contents($versionUrl, false, $context);
        return $remoteVersion ? trim($remoteVersion) : false;
    }

    /**
     * Obtém a URL de download do plugin.
     */
    private function getDownloadUrl()
    {
        return 'https://github.com/irpub/irpxv/releases/latest/download/IRXMLViewer.zip';
    }

    /* --- Funções Auxiliares --- */
    private function _getJQueryUrl($request) {
        if ($this->isOJS34()) {
            $min = \PKP\config\Config::getVar('general', 'enable_minified') ? '.min' : '';
        } else {
            $min = Config::getVar('general', 'enable_minified') ? '.min' : '';
        }
        return $request->getBaseUrl() . '/lib/pkp/lib/vendor/components/jquery/jquery' . $min . '.js';
    }
    
    public function getIRXmlPath($request) {
        return $request->getBaseUrl() . '/' . $this->getPluginPath() . '/lib/irxml';
    }
}

// --- Alias de Compatibilidade de Namespace ---
// Se estivermos no OJS 3.4+, criamos um alias da nossa classe global
// para o namespace que o OJS 3.4+ espera.
if (class_exists('APP\core\Application')) {
    class_alias('IRXmlViewerPlugin', 'APP\plugins\generic\IRXmlViewer\IRXmlViewerPlugin');
}