<?php

/**
    # Licença de Uso Exclusivo:
    # Este código é proprietário e confidencial. Seu uso é estritamente limitado a assinantes
    # que tenham pago a taxa de assinatura mensal. Qualquer uso não autorizado, reprodução ou modificação
    # deste código é estritamente proibido. Para consultas sobre licenciamento e assinatura,
    # entre em contato com IR Publicações e Desenvolvimento.

    # Exclusive Use License:
    # This code is proprietary and confidential. Its use is strictly limited to subscribers
    # who have paid the monthly subscription fee. Any unauthorized use, reproduction, or modification
    # of this code is strictly prohibited. For inquiries regarding licensing and subscription,
    # please contact IR Publicações e Desenvolvimento.
 */

import('lib.pkp.classes.plugins.GenericPlugin');
import('lib.pkp.classes.linkAction.LinkAction');
import('lib.pkp.classes.linkAction.request.AjaxModal');
import('lib.pkp.classes.core.JSONMessage');
import('plugins.generic.IRXmlViewer.SettingsForm');

class IRXmlViewerPlugin extends GenericPlugin
{
    /**
     * @copydoc LazyLoadPlugin::register()
     *
     * @param null|mixed $mainContextId
     */
    public function register($category, $path, $mainContextId = null)
    {
        if (parent::register($category, $path, $mainContextId)) {
            if ($this->getEnabled()) {
                // Add the minor update check
                $this->checkForMinorUpdates();
                HookRegistry::register('ArticleHandler::view::galley', array($this, 'articleCallback'));
                HookRegistry::register('IssueHandler::view::galley', array($this, 'issueCallback'));
                HookRegistry::register('ArticleHandler::download', array($this, 'articleDownloadCallback'), HOOK_SEQUENCE_LATE);
                HookRegistry::register('ArticleHandler::view::galley', array($this, 'callbackAddLinks'));

                // Forçar o carregamento das traduções
                $locale = AppLocale::getLocale();
                $translationFile = $this->getPluginPath() . "/locale/$locale/locale.po";
                $defaultTranslationFile = $this->getPluginPath() . "/locale/en_US/locale.po";

                // Tenta carregar o arquivo de tradução do idioma atual
                if (file_exists($translationFile)) {
                    AppLocale::registerLocaleFile($locale, $translationFile);
                } elseif (file_exists($defaultTranslationFile)) {
                    // Se o arquivo de tradução no idioma atual não existir, usa o inglês como fallback
                    AppLocale::registerLocaleFile('en_US', $defaultTranslationFile);
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Install default settings on journal creation.
     *
     * @return string
     */
    public function getContextSpecificPluginSettingsFile()
    {
        return $this->getPluginPath() . '/settings.xml';
    }

    /**
     * Get the display name of this plugin.
     *
     * @return string
     */
    public function getDisplayName()
    {
        return __('plugins.generic.IRXmlViewer.displayName');
    }

    /**
     * Get a description of the plugin.
     */
    public function getDescription()
    {
        return __('plugins.generic.IRXmlViewer.description');
    }

    /**
     * Callback that renders the article galley.
     *
     * @param string $hookName
     * @param array $args
     *
     * @return bool
     */
    public function articleCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];
        $submission = &$args[3];

        $templateMgr = TemplateManager::getManager($request);
        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $galleyPublication = null;
            foreach ($submission->getData('publications') as $publication) {
                if ($publication->getId() === $galley->getData('publicationId')) {
                    $galleyPublication = $publication;
                    break;
                }
            }

            // Assign the showCitation variable
            $journalId = $request->getJournal()->getId();
            $showCitation = $this->getSetting($journalId, 'showCitation');
            $templateMgr->assign('showCitation', $showCitation);

            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'article' => $submission,
                'bestId' => $submission->getBestId(),
                'isLatestPublication' => $submission->getData('currentPublicationId') === $galley->getData('publicationId'),
                'galleyPublication' => $galleyPublication,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
            ]);
            $templateMgr->display($this->getTemplateResource('articleGalley.tpl'));
            return true;
        }

        return false;
    }

    /**
     * Callback that renders the issue galley.
     *
     * @param string $hookName
     * @param array $args
     *
     * @return bool
     */
    public function issueCallback($hookName, $args)
    {
        $request = &$args[0];
        $issue = &$args[1];
        $galley = &$args[2];

        $templateMgr = TemplateManager::getManager($request);
        if ($galley && in_array($galley->getFileType(), ['application/xml', 'text/xml'])) {
            $templateMgr->assign([
                'pluginIRXmlPath' => $this->getIRXmlPath($request),
                'displayTemplatePath' => $this->getTemplateResource('display.tpl'),
                'pluginUrl' => $request->getBaseUrl() . '/' . $this->getPluginPath(),
                'galleyFile' => $galley->getFile(),
                'issue' => $issue,
                'galley' => $galley,
                'jQueryUrl' => $this->_getJQueryUrl($request),
            ]);
            $templateMgr->display($this->getTemplateResource('issueGalley.tpl'));
            return true;
        }

        return false;
    }

    /**
     * Get the URL for JQuery JS.
     *
     * @param PKPRequest $request
     *
     * @return string
     */
    private function _getJQueryUrl($request)
    {
        $min = Config::getVar('general', 'enable_minified') ? '.min' : '';
        return $request->getBaseUrl() . '/lib/pkp/lib/vendor/components/jquery/jquery' . $min . '.js';
    }

    /**
     * returns the base path for IRXml JS included in this plugin.
     *
     * @param PKPRequest $request
     *
     * @return string
     */
    public function getIRXmlPath($request)
    {
        return $request->getBaseUrl() . '/' . $this->getPluginPath() . '/lib/irxml';
    }

    /**
     * Present rewritten XML.
     *
     * @param string $hookName
     * @param array $args
     */
    public function articleDownloadCallback($hookName, $args)
    {
        $article =& $args[0];
        $galley =& $args[1];
        $fileId =& $args[2];
        $request = Application::get()->getRequest();

        if ($galley && in_array($galley->getFileType(), array('application/xml', 'text/xml')) && $galley->getFileId() == $fileId) {
            if (!HookRegistry::call('IRXmlViewerPlugin::articleDownload', array($article, &$galley, &$fileId))) {
                $xmlContents = $this->_getXMLContents($request, $galley);
                header('Content-Type: application/xml');
                header('Content-Length: ' . strlen($xmlContents));
                header('Content-Disposition: inline');
                header('Cache-Control: private');
                header('Pragma: public');
                echo $xmlContents;
                $returner = true;
                HookRegistry::call('IRXmlViewerPlugin::articleDownloadFinished', array(&$returner));
            }
            return true;
        }

        return false;
    }

    /**
     * Return string containing the contents of the XML file.
     * This function performs any necessary filtering, like image URL replacement.
     *
     * @param Request $request
     * @param Galley $galley
     *
     * @return string
     */
    public function _getXMLContents($request, $galley)
    {
        $journal = $request->getJournal();
        $submissionFile = $galley->getFile();
        $fileService = Services::get('file');
        $file = $fileService->get($submissionFile->getData('fileId'));
        $contents = $fileService->fs->read($file->path);

        //Add <sub-articles>
        // Load the XML string into SimpleXML
        $dom = new \DOMDocument(); // Adicione uma barra antes de DOMDocument para indicar o namespace global
        $dom->loadXML($contents, LIBXML_NOBLANKS);

        // Get the <body> of the main <article>
        $mainBody = $dom->getElementsByTagName('body')->item(0);

        // Get the <body> of the <sub-article>
        $subArticle = $dom->getElementsByTagName('sub-article')->item(0);
        $subArticleLang = $subArticle->getAttribute('xml:lang');
        $subArticleBody = $subArticle->getElementsByTagName('body')->item(0);

        if ($mainBody && $subArticleBody) {
            // Create the new <sec> element with a <p> element inside it
            $secElement = $dom->createElement('sec');
            $secElement->setAttribute('sec-type', $subArticleLang);
            $secElement->setAttribute('xml:lang', $subArticleLang);

            $pElement = $dom->createElement('title', strtoupper($subArticleLang));
            $secElement->appendChild($pElement);

            // Append the <sec> element to the main <body>
            $mainBody->appendChild($secElement);

            // Move each child node from <sub-article> <body> into the main <article> <body>
            while ($subArticleBody->firstChild) {
                $node = $subArticleBody->removeChild($subArticleBody->firstChild);
                $mainBody->appendChild($dom->importNode($node, true));
            }
        }

        // Move and modify <fn-group> elements from <sub-article> to <article> <back>
        $mainBack = $dom->getElementsByTagName('back')->item(0);
        $subArticleFnGroups = $subArticle->getElementsByTagName('fn-group');

        foreach ($subArticleFnGroups as $fnGroup) {
            // Clone each <fn-group> and add fn-group-lang attribute
            $importedFnGroup = $dom->importNode($fnGroup, true);
            $importedFnGroup->setAttribute('fn-group-lang', $subArticleLang);

            // Append modified <fn-group> to the main <article> <back>
            $mainBack->appendChild($importedFnGroup);
        }
        // Output the modified XML as a string
        $contents = $dom->saveXML();

        $contents = str_replace('.tif"/>', '.jpg"/>', $contents);

        // Replace media file references
        import('lib.pkp.classes.submission.SubmissionFile'); // Constants
        $embeddableFilesIterator = Services::get('submissionFile')->getMany([
            'assocTypes' => [ASSOC_TYPE_SUBMISSION_FILE],
            'assocIds' => [$submissionFile->getId()],
            'fileStages' => [SUBMISSION_FILE_DEPENDENT],
            'includeDependentFiles' => true,
        ]);
        $embeddableFiles = iterator_to_array($embeddableFilesIterator);
        $referredArticle = $referredPublication = null;
        $submissionDao = DAORegistry::getDAO('SubmissionDAO');
        $publicationService = Services::get('publication');
        foreach ($embeddableFiles as $embeddableFile) {
            // Ensure that the $referredArticle object refers to the article we want
            if (!$referredArticle || !$referredPublication || $referredPublication->getData('submissionId') != $referredArticle->getId() || $referredPublication->getId() != $galley->getData('publicationId')) {
                $referredPublication = $publicationService->get($galley->getData('publicationId'));
                $referredArticle = $submissionDao->getById($referredPublication->getData('submissionId'));
            }
            $fileUrl = $request->url(null, 'article', 'download', [$referredArticle->getBestArticleId(), $galley->getBestGalleyId(), $embeddableFile->getId()]);
            $pattern = preg_quote(rawurlencode($embeddableFile->getLocalizedData('name')));

            $contents = preg_replace(
                $pattern = '/([Ss][Rr][Cc]|[Hh][Rr][Ee][Ff]|[Dd][Aa][Tt][Aa])\s*=\s*"([^"]*' . $pattern . ')"/',
                '\1="' . $fileUrl . '"',
                $contents
            );
            if ($contents === null)
                error_log('PREG error in ' . __FILE__ . ' line ' . __LINE__ . ': ' . preg_last_error());
        }

        // Perform replacement for ojs://... URLs
        $contents = preg_replace_callback(
            '/(<[^<>]*")[Oo][Jj][Ss]:\/\/([^"]+)("[^<>]*>)/',
            array($this, '_handleOjsUrl'),
            $contents
        );
        if ($contents === null) {
            error_log('PREG error in ' . __FILE__ . ' line ' . __LINE__ . ': ' . preg_last_error());
        }

        // Perform variable replacement for journal, issue, site info
        $issueDao = DAORegistry::getDAO('IssueDAO');
        $issue = $issueDao->getBySubmissionId($galley->getData('submissionId'));

        $journal = $request->getJournal();
        $site = $request->getSite();

        $paramArray = [
            'issueTitle' => $issue ? $issue->getIssueIdentification() : __('editor.article.scheduleForPublication.toBeAssigned'),
            'journalTitle' => $journal->getLocalizedName(),
            'siteTitle' => $site->getLocalizedTitle(),
            'currentUrl' => $request->getRequestUrl(),
        ];

        foreach ($paramArray as $key => $value) {
            if ($value !== null) {
                $contents = str_replace('{$' . $key . '}', $value, $contents);
            } else {
                // Replace with an empty string or just skip
                $contents = str_replace('{$' . $key . '}', '', $contents);
            }
        }

        $contents = str_replace('&amp;', '@@1AMP1@@', $contents);
        $contents = str_replace('&gt;', '@@1GT1@@', $contents);
        $contents = str_replace('&lt;', '@@1LT1@@', $contents);

        // Decode remaining HTML entities
        $contents = html_entity_decode($contents, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $contents = str_replace(array("@@1LT1@@", "@@1GT1@@", "@@1AMP1@@"), array("&lt;", "&gt;", "&amp;"), $contents);

        return $contents;
    }

    public function _handleOjsUrl($matchArray)
    {
        $request = Application::get()->getRequest();
        $url = $matchArray[2];
        $anchor = null;
        if (($i = strpos($url, '#')) !== false) {
            $anchor = substr($url, $i + 1);
            $url = substr($url, 0, $i);
        }
        $urlParts = explode('/', $url);
        if (isset($urlParts[0])) {
            switch (strtolower($urlParts[0])) {
                case 'journal':
                    $url = $request->url(
                        isset($urlParts[1]) ? $urlParts[1] : $request->getRouter()->getRequestedContextPath($request),
                        null,
                        null,
                        null,
                        null,
                        $anchor
                    );
                    break;
                case 'article':
                    if (isset($urlParts[1])) {
                        $url = $request->url(
                            null,
                            'article',
                            'view',
                            $urlParts[1],
                            null,
                            $anchor
                        );
                    }
                    break;
                case 'issue':
                    if (isset($urlParts[1])) {
                        $url = $request->url(
                            null,
                            'issue',
                            'view',
                            $urlParts[1],
                            null,
                            $anchor
                        );
                    } else {
                        $url = $request->url(
                            null,
                            'issue',
                            'current',
                            null,
                            null,
                            $anchor
                        );
                    }
                    break;
                case 'sitepublic':
                    array_shift($urlParts);
                    $publicFileManager = new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getSiteFilesPath() . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
                case 'public':
                    array_shift($urlParts);
                    $journal = $request->getJournal();
                    $publicFileManager = new PublicFileManager();
                    $url = $request->getBaseUrl() . '/' . $publicFileManager->getContextFilesPath($journal->getId()) . '/' . implode('/', $urlParts) . ($anchor ? '#' . $anchor : '');
                    break;
            }
        }
        return $matchArray[1] . $url . $matchArray[3];
    }

    public function callbackAddLinks($hookName, $args)
    {
        $request = Application::get()->getRequest();
        if ($this->getEnabled() && is_a($request->getRouter(), 'PKPPageRouter')) {
            $templateManager = $args[0];
            $currentJournal = $templateManager->get_template_vars('currentJournal');

            $displayPage = $currentJournal ? $this->getSetting($currentJournal->getId(), 'displayPage') : null;
        }

        return false;
    }

    public function getActions($request, $verb)
    {
        $router = $request->getRouter();
        return array_merge(
            $this->getEnabled($request->getContext()->getId()) ? array(
                new LinkAction(
                    'settings',
                    new AjaxModal(
                        $router->url($request, null, null, 'manage', null, array('verb' => 'settings', 'plugin' => $this->getName(), 'category' => 'generic')),
                        $this->getDisplayName()
                    ),
                    __('manager.plugins.settings'),
                    null
                ),
            ) : array(),
            parent::getActions($request, $verb)
        );
    }

    public function manage($args, $request)
    {
        switch ($request->getUserVar('verb')) {
            case 'settings':
                $context = $request->getContext();
                $templateMgr = TemplateManager::getManager($request);
                $templateMgr->register_function('plugin_url', array($this, 'smartyPluginUrl'));

                // Read the version here
                $versionFilePath = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'version.txt';
                if (file_exists($versionFilePath)) {
                    $version = trim(file_get_contents($versionFilePath));
                } else {
                    $version = 'Desconhecida';
                }
                $templateMgr->assign('pluginVersion', $version);

                // Ensure that the SettingsForm class is available
                $form = new SettingsForm($this, $context->getId());

                if ($request->getUserVar('save') || $request->getUserVar('forceUpdate')) {
                    $form->readInputData();
                    if ($form->validate()) {
                        $form->execute();
                        if ($request->getUserVar('forceUpdate')) {
                            $this->forceUpdate();
                            return new JSONMessage(true, __('plugins.generic.IRXmlViewer.updateSuccess'));
                        }
                        return new JSONMessage(true);
                    }
                } else {
                    $form->initData();
                }
                return new JSONMessage(true, $form->fetch($request));
        }
        return parent::manage($args, $request);
    }

    public function forceUpdate()
    {
        $errors = [];

        // Download update.zip
        $updateZipUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/3.zip';
        $updateZipPath = $this->getPluginPath() . '/update.zip';

        $downloaded = @file_put_contents($updateZipPath, fopen($updateZipUrl, 'r'));
        if (!$downloaded) {
            $errors[] = 'Erro: Falha ao baixar o arquivo update.zip da URL: ' . $updateZipUrl;
            $this->logErrors($errors);
            return ['success' => false, 'message' => '<br><b>Erro 101 - Falha ao baixar os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 101.<br>'];
        }

        // Unzip update.zip into a temporary directory
        $zip = new \ZipArchive;
        if ($zip->open($updateZipPath) === TRUE) {
            $extractPath = $this->getPluginPath() . '/update_temp';
            if (!$zip->extractTo($extractPath)) {
                $errors[] = 'Erro: Falha ao extrair o arquivo update.zip para o diretório temporário.';
                $this->logErrors($errors);
                $zip->close();
                unlink($updateZipPath);
                return ['success' => false, 'message' => '<br><b>Erro 102 - Falha ao extrair os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 102.<br>'];
            }
            $zip->close();
        } else {
            $errors[] = 'Erro: Não foi possível abrir o arquivo update.zip.';
            $this->logErrors($errors);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 103 - Falha ao abrir os arquivos</b><br>Acesse a documentação para mais informações sobre o erro 103.<br>'];
        }

        // Now, replace plugin files with the ones from the update
        if (!$this->recurseCopy($extractPath, $this->getPluginPath())) {
            $errors[] = 'Erro: Falha ao copiar os arquivos do diretório de atualização para o diretório do plugin.';
            $this->logErrors($errors);
            $this->rrmdir($extractPath);
            unlink($updateZipPath);
            return ['success' => false, 'message' => '<br><b>Erro 104 - Falha ao aplicar a atualização</b><br>Acesse a documentação para mais informações sobre o erro 104.<br>'];
        }

        // Remove the temporary files
        $this->rrmdir($extractPath);
        unlink($updateZipPath);

        // Now, check for updates
        $remoteVersionUrl = 'https://raw.githubusercontent.com/irpub/irpxv/main/version3';

        // Read remote version
        $remoteVersion = trim(@file_get_contents($remoteVersionUrl));

        // Atualiza o arquivo de versão local
        $localVersionFile = $this->getPluginPath() . '/version.txt';
        file_put_contents($localVersionFile, $remoteVersion);

        // Update success
        return ['success' => true];
    }

    public function checkForMinorUpdates()
    {
        $context = Application::get()->getRequest()->getContext();
        $contextId = $context ? $context->getId() : CONTEXT_ID_NONE;

        // Get last check time from settings
        $lastCheckTime = $this->getSetting($contextId, 'lastUpdateCheck');
        $currentTime = time();

        $localVersionFile = $this->getPluginPath() . '/version.txt';

        // Read local version
        if (!file_exists($localVersionFile)) {
            // No local version file, assume version 0.0.0
            $localVersion = '0.0.0';
        } else {
            $localVersion = trim(file_get_contents($localVersionFile));
        }

        // Check if one hour has passed since last check
        if ($lastCheckTime && ($currentTime - $lastCheckTime) < 28800 && $localVersion != '0.0.0') {
            // Less than one hour since last check, do nothing
            return;
        }

        // Update the last check time
        $this->updateSetting($contextId, 'lastUpdateCheck', $currentTime);

        // Now, check for updates
        $remoteVersionUrl = 'https://raw.githubusercontent.com/murilloac995/irpxv/main/version3';

        // Read remote version
        $remoteVersion = trim(@file_get_contents($remoteVersionUrl));
        if (!$remoteVersion) {
            // Could not get remote version, abort
            return;
        }

        // Compare versions
        if (version_compare($remoteVersion, $localVersion, '>')) {
            // Remote version is newer, proceed to update
            $this->performMinorUpdate($remoteVersion);
        }
    }

    public function performMinorUpdate($newVersion)
    {
        // Download update.zip
        $updateZipUrl = 'https://raw.githubusercontent.com/murilloac995/irpxv/main/3.zip';
        $updateZipPath = $this->getPluginPath() . '/update.zip';

        // Download the zip file
        $downloaded = @file_put_contents($updateZipPath, fopen($updateZipUrl, 'r'));
        if (!$downloaded) {
            // Could not download update.zip
            return;
        }

        // Unzip update.zip into a temporary directory
        $zip = new \ZipArchive;
        if ($zip->open($updateZipPath) === TRUE) {
            $extractPath = $this->getPluginPath() . '/update_temp';
            $zip->extractTo($extractPath);
            $zip->close();
        } else {
            // Could not open zip file
            unlink($updateZipPath);
            return;
        }

        // Now, replace plugin files with the ones from the update
        $this->recurseCopy($extractPath, $this->getPluginPath());

        // Remove the temporary files
        $this->rrmdir($extractPath);
        unlink($updateZipPath);

        // Update local version file
        $localVersionFile = $this->getPluginPath() . '/version.txt';
        file_put_contents($localVersionFile, $newVersion);
    }

    /**
     * Recursively delete a directory
     *
     * @param string $dir
     */
    private function rrmdir($dir)
    {
        // Define the path to the error log file
        $errorLogFile = $this->getPluginPath() . '/errors.txt';

        if (is_dir($dir)) {
            $objects = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );

            foreach ($objects as $object) {
                $path = $object->getPathname();
                if ($object->isDir()) {
                    if (!rmdir($path)) {
                        // Log the error with date and time to errors.txt
                        file_put_contents(
                            $errorLogFile,
                            '[' . date('Y-m-d H:i:s') . '] Failed to remove directory: ' . $path . PHP_EOL,
                            FILE_APPEND
                        );
                    }
                } else {
                    if (!unlink($path)) {
                        // Log the error with date and time to errors.txt
                        file_put_contents(
                            $errorLogFile,
                            '[' . date('Y-m-d H:i:s') . '] Failed to delete file: ' . $path . PHP_EOL,
                            FILE_APPEND
                        );
                    }
                }
            }

            if (!rmdir($dir)) {
                // Log the error with date and time to errors.txt
                file_put_contents(
                    $errorLogFile,
                    '[' . date('Y-m-d H:i:s') . '] Failed to remove root directory: ' . $dir . PHP_EOL,
                    FILE_APPEND
                );
            }
        } else {
            // Log the error with date and time to errors.txt
            file_put_contents(
                $errorLogFile,
                '[' . date('Y-m-d H:i:s') . '] Directory does not exist or is not a directory: ' . $dir . PHP_EOL,
                FILE_APPEND
            );
        }
    }

    /**
     * Recursively copy files from one directory to another.
     *
     * @param string $src
     * @param string $dst
     */
    private function recurseCopy($src, $dst)
    {
        $dir = opendir($src);
        @mkdir($dst);
        while (false !== ($file = readdir($dir))) {
            if (($file != '.') && ($file != '..')) {
                if (is_dir($src . '/' . $file)) {
                    $this->recurseCopy($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
}
?>